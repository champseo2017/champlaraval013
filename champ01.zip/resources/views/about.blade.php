@extends('layout.app')
@section('content')
<h1>About</h1>
@endsection