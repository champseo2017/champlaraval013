@extends('layout.app')
@section('content')
<h1>Contact</h1>
@endsection