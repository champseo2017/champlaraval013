@section('sidebar')
	<div class="sidebar">
	<h3>sidebar</h3>
	This is the sidebar
	@show
	</div>