<?php $__env->startSection('sidebar'); ?>
	<div class="sidebar">
	<h3>sidebar</h3>
	This is the sidebar
	<?php echo $__env->yieldSection(); ?>
	</div>